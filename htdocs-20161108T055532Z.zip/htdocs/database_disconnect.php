<?php
$mysql->close();
unset($mysql);
?>