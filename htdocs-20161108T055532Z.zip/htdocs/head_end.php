<?php
/*
 * See head_start.php for more information.
 */
?>


<?php
if (!isset($PageTitle)) {
    $PageTitle = "Default";
}
?>

    <title>E.O.L.M.S - <?php echo $PageTitle; ?></title>
</head>

