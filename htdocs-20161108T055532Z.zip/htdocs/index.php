<?php

header("Location: login.php");
die();

?>